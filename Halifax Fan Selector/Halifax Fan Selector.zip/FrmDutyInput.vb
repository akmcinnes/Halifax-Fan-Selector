﻿Public Class FrmDutyInput
    Private Sub FrmDutyInput_Load(sender As Object, e As EventArgs) Handles Me.Load
        CenterToScreen()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub
End Class